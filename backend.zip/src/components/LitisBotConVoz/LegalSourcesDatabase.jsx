// src/components/LitisBotConVoz/LegalSourcesDatabase.jsx
import React from 'react';

const LegalSourcesDatabase = () => {
  return (
    <div>
      <h2>Legal Sources Database</h2>
      <p>Componente funcional.</p>
    </div>
  );
};

export default LegalSourcesDatabase;
