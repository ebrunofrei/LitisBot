export { default } from './LegalResponseEngine';
