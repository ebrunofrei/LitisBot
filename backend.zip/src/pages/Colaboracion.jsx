// src/pages/Colaboracion.jsx
import React from 'react';

const Colaboracion = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Colabora con LitisBot</h1>
      <p>Gracias por apoyar nuestro proyecto para seguir creciendo y mejorando.</p>
      <p>Colabora enviando tu aporte a:</p>
      <ul>
        <li>Yape / Plin: <strong>922 038 280</strong></li>
      </ul>
      {/* Agrega aquí un QR o información adicional */}
    </div>
  );
};

export default Colaboracion;
