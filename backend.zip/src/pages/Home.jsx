// src/pages/Home.jsx
import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Bienvenido a LitisBot</h1>
      <p>Esta es la página principal de tu aplicación legal. Aquí podrás acceder a todas las funcionalidades del sistema.</p>
      {/* Puedes agregar enlaces o información adicional */}
    </div>
  );
};

export default Home;
